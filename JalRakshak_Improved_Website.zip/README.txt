JalRakshak Improved Website

The homepage now displays each PowerPoint slide as an image directly (not inside a PDF iframe), with next/previous controls, thumbnails, full-screen viewing, and searchable slide topics.

Keep the following structure exactly:
- index.html
- presentation.pdf
- presentation.pptx
- slides/slide-1.png through slides/slide-5.png

For a public website, upload ALL files and the slides folder to the root of a GitHub repository, then enable GitHub Pages in Settings > Pages > Deploy from a branch > main > /(root). The public URL will be supplied by GitHub Pages.
